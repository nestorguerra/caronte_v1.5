# 🎮 MIS JUEGOS PREFES 🎮

¡¡Hola!! Me llamo Leo y tengo 9 años. Esta es mi plataforma de juegos que hice con mi papa. Son los juegos mas chulos del mundo mundial y me encantan muchisimo!!!

## 🚗 LEO RACING

Este es mi juego favorito!!! Es un juego de coches de carreras como los de las maquinitas antiguas. Yo soy el piloto y tengo un Ferrari rojo super chulo que va MUY rapido.

**Como se juega:**
- Con las flechas ⬅️ ➡️ giras el coche
- Con la flecha ⬆️ aceleras a tope
- Con la flecha ⬇️ frenas (pero yo nunca freno jeje)
- Con ESPACIO usas el TURBO 🔥🔥🔥

**Los otros coches:**
- **JORGE** - Es el coche rojo y siempre va por la izquierda
- **ALEX** - Es el coche azul y siempre va por la derecha
- **ISA** - Es el coche verde y va por el medio

Tienes que hacer 3 vueltas y ganarles a todos!! El circuito se llama Costa del Sol y tiene curvas muy dificiles pero yo ya me las se todas 😎

## 👑 LEO VS LOS REYES MAGOS

Este juego es super divertido!! Los Reyes Magos estan tirando regalos desde el cielo y yo tengo que cogerlos todos con mi saco magico.

**Como se juega:**
- Te mueves con las flechas ⬅️ ➡️
- Tienes que coger los regalos que caen
- Cuidado con las cosas malas que tambien caen!!
- Cuantos mas regalos coges mas puntos tienes

Es muy chulo porque es de Navidad y salen Melchor, Gaspar y Baltasar que son mis favoritos!!

## ⛏️ LEO MINECRAFT ADVENTURE

Este juego es como Minecraft pero en 2D!! Puedes explorar, romper bloques y construir cosas. A mi me encanta Minecraft y por eso mi papa me ayudo a hacer este.

**Como se juega:**
- Te mueves con las flechas
- Rompes bloques haciendo clic
- Puedes construir cosas super chulas
- Hay zombies y esqueletos pero no dan mucho miedo

## 🏛️ ACROPOLIS TREASURE HUNT

Este es un juego de aventuras en Grecia antigua!! Tienes que buscar tesoros por toda la Acropolis que es un sitio muy antiguo con columnas muy grandes.

**Como se juega:**
- Exploras el mapa buscando tesoros
- Tienes que resolver puzzles
- Hay trampas y enemigos
- Al final encuentras el tesoro mas grande!!

Mi papa me conto que la Acropolis esta en Atenas y que es muy muy vieja, de hace miles de años!

---

## 💻 Como jugar

Es muy facil!! Solo tienes que:

1. Abrir el archivo `index.html` en el navegador
2. Elegir el juego que quieras
3. JUGAR Y PASARTELO BIEN!! 🎉

## 📁 Los archivos

| Archivo | Que es |
|---------|--------|
| `index.html` | La plataforma donde eliges el juego |
| `leo-racing.html` | El juego de coches |
| `leo-vs-reyes-magos.html` | El juego de los Reyes Magos |
| `leo-minecraft-adventure.html` | El juego tipo Minecraft |
| `acropolis-treasure-hunt.html` | El juego de buscar tesoros |

## 🙏 Agradecimientos

**GRACIAS PAPA** por ayudarme a hacer estos juegos tan chulos!! Eres el mejor papa del mundo!! ❤️

Tambien gracias a mis amigos Jorge, Alex e Isa por salir en el juego de coches!!

---

*2026 - Papa me ha ayudado con mucho ❤️*

**PD:** Si no te funcionan los juegos preguntale a un adulto que te ayude con el ordenador 😄
